# Integração dos chamados

O front-end React conversa com a API do Laravel. A API persiste os chamados na tabela `chamados` e a Inbox consulta essa tabela ao abrir; assim, um chamado recém-criado continua aparecendo após atualizar a página.

## Pré-requisitos

- PHP 8.2+ e extensões exigidas pelo Laravel (PDO para o banco escolhido).
- Composer.
- Node.js e npm.
- Um banco configurado no Laravel. A configuração atual do projeto usa MySQL; SQLite também pode ser usado para desenvolvimento.

## Preparar o back-end

A partir de `src/backend`:

```bash
composer install
test -f .env || cp .env.example .env
php artisan key:generate
```

Edite `src/backend/.env` para apontar `DB_CONNECTION`, host, porta, nome, usuário e senha do seu MySQL (ou configure SQLite). Não publique nem compartilhe o arquivo `.env`.

Crie a estrutura e, se desejar, carregue os dados de exemplo:

```bash
php artisan migrate
php artisan db:seed
php artisan serve --host=127.0.0.1 --port=8000
```

A pasta `src/backend/database/migrations` foi atualizada com as migrations enviadas em `migrations.zip`. A migração `2026_10_07_000001_add_frontend_fields_to_chamados_table.php` acrescenta sala e dispositivo digitados no formulário, timestamps necessários e permite que o vínculo com um usuário/equipamento seja nulo quando ainda não há correspondência no catálogo.

A migração `2026_10_07_000002_expand_senha_for_hashes.php` amplia `usuarios.senha` para 255 caracteres, permite contas de exemplo sem senha e converte senhas legadas em texto puro para hash antes do login.

## Preparar o front-end

Em outro terminal, a partir de `src/frontend`:

```bash
npm install
npm run dev
```

No desenvolvimento, o Vite encaminha `/api` para `http://127.0.0.1:8000`. Para apontar a API para outro endereço, defina `BACKEND_URL` antes de iniciar o Vite. Em uma hospedagem de produção com API em outro domínio, configure `VITE_API_URL` com a origem do Laravel, por exemplo `https://api.exemplo.com` (sem `/api` no final).

## Endpoints

- `GET /api/chamados`: lista chamados persistidos.
- `POST /api/chamados`: cria um chamado. O corpo JSON requer `sala`, `dispositivo`, `categoria` (`Hardware` ou `Software`) e `descricao` (até 150 caracteres, conforme a coluna existente).
- `DELETE /api/chamados/{id}`: exclui permanentemente o chamado do banco. A lixeira da Inbox chama esse endpoint para cada item selecionado.
- `POST /api/auth/register`: cadastra `nome`, `rm`, `email` e `senha`. O email e o RM devem ser únicos; a senha precisa ter de 8 a 72 caracteres.
- `POST /api/auth/login`: recebe `login` (email ou RM) e `senha` e valida as credenciais persistidas.

As senhas são gravadas na coluna `usuarios.senha` usando o hash do Laravel; a senha em texto puro nunca é salva nem devolvida pela API. Usuários de exemplo sem senha não podem fazer login até que definam credenciais válidas.
